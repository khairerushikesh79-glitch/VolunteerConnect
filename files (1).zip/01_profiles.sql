-- Run in Supabase: SQL Editor -> New query -> paste -> Run

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'citizen' check (role in ('citizen','volunteer','ngo','admin')),
  organization text,
  created_at timestamptz not null default now()
);

-- Create a profile automatically when someone signs up.
-- Only citizen, volunteer and ngo can be chosen at signup; anything else becomes citizen.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  chosen text := coalesce(new.raw_user_meta_data->>'role', 'citizen');
begin
  if chosen not in ('citizen','volunteer','ngo') then
    chosen := 'citizen';
  end if;
  insert into public.profiles (id, full_name, role, organization)
  values (new.id,
          coalesce(new.raw_user_meta_data->>'full_name', ''),
          chosen,
          nullif(new.raw_user_meta_data->>'organization', ''));
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Helper so policies can check for admins without recursion
create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

-- Row-level security
alter table public.profiles enable row level security;

create policy "Users read own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Admins read all profiles"
  on public.profiles for select
  using (public.is_admin());

create policy "Users update own profile"
  on public.profiles for update
  using (auth.uid() = id)
  with check (auth.uid() = id);

-- Users may edit only their name and organization, never their role
revoke update on public.profiles from authenticated;
grant update (full_name, organization) on public.profiles to authenticated;

-- To make yourself an admin (run manually, replace the email):
-- update public.profiles set role = 'admin'
--   where id = (select id from auth.users where email = 'you@example.com');
