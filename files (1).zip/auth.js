// Shared authentication helpers. Load after supabase-config.js.
const DASHBOARDS = {
  citizen: 'citizen-dashboard.html',
  volunteer: 'volunteer-dashboard.html',
  ngo: 'ngo-dashboard.html',
  admin: 'admin-dashboard.html'
};

async function getProfile() {
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return null;
  const { data, error } = await sb.from('profiles').select('*').eq('id', user.id).single();
  if (error) return null;
  return data;
}

async function redirectByRole() {
  const profile = await getProfile();
  if (!profile) return false;
  window.location.href = DASHBOARDS[profile.role] || 'index.html';
  return true;
}

// Call on each dashboard page. Sends visitors to login if not signed in
// or to their own dashboard if they open the wrong one.
async function requireRole(role) {
  const profile = await getProfile();
  if (!profile) { window.location.href = 'login.html'; return null; }
  if (profile.role !== role) { window.location.href = DASHBOARDS[profile.role]; return null; }
  return profile;
}

async function logout() {
  await sb.auth.signOut();
  window.location.href = 'index.html';
}
