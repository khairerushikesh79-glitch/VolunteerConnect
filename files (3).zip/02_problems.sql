-- Run in Supabase SQL Editor after 01_profiles.sql

-- Helper: role of the logged-in user (used by policies)
create or replace function public.current_user_role()
returns text
language sql
security definer
set search_path = public
stable
as $$
  select role from public.profiles where id = auth.uid();
$$;

-- Categories ---------------------------------------------------------
create table public.categories (
  id serial primary key,
  name text not null unique,
  kind text not null default 'problem' check (kind in ('problem','activity'))
);
insert into public.categories (name, kind) values
  ('Garbage and waste','problem'), ('Road damage','problem'), ('Water supply','problem'),
  ('Streetlight','problem'), ('Drainage and flooding','problem'), ('Trees and parks','problem'),
  ('Other','problem');

alter table public.categories enable row level security;
create policy "Anyone can read categories" on public.categories for select using (true);

-- Problems -----------------------------------------------------------
create table public.problems (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  category_id int not null references public.categories(id),
  title text not null check (char_length(title) between 3 and 120),
  description text not null check (char_length(description) between 5 and 2000),
  photo_path text,
  latitude double precision not null check (latitude between -90 and 90),
  longitude double precision not null check (longitude between -180 and 180),
  address text,
  status text not null default 'reported'
    check (status in ('reported','verified','assigned','in_progress','resolved')),
  created_at timestamptz not null default now()
);
create index problems_reporter_idx on public.problems (reporter_id, created_at desc);

alter table public.problems enable row level security;

create policy "Citizens report problems" on public.problems for insert
  with check (reporter_id = auth.uid() and status = 'reported' and public.current_user_role() = 'citizen');

create policy "Reporters read own problems" on public.problems for select
  using (reporter_id = auth.uid());

create policy "NGOs and admins read all problems" on public.problems for select
  using (public.current_user_role() in ('ngo','admin'));

-- No update/delete policies yet: status changes will be added with NGO/admin work in later phases.

-- Photo storage ------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('problem-photos', 'problem-photos', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

-- Logged-in users may upload only into a folder named after their own user id
create policy "Upload own problem photos" on storage.objects for insert to authenticated
  with check (bucket_id = 'problem-photos' and (storage.foldername(name))[1] = auth.uid()::text);
