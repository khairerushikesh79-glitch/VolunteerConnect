// Citizen views: report a problem and track reports. Loaded after dashboard.js.
const STATUS_STEPS = [['reported', 'Reported'], ['verified', 'Verified'], ['assigned', 'Assigned'], ['in_progress', 'In progress'], ['resolved', 'Resolved']];
const MAX_PHOTO = 5 * 1024 * 1024;
let reportMap = null;

function photoUrl(path) {
  return path ? sb.storage.from('problem-photos').getPublicUrl(path).data.publicUrl : null;
}

async function renderReportForm(view, profile) {
  view.innerHTML = '<h1>Report a problem</h1><p class="sub">Describe the issue and mark where it is.</p><div class="panel" id="formBox">Loading…</div>';
  const { data: cats } = await sb.from('categories').select('id, name').eq('kind', 'problem').order('id');
  const box = document.getElementById('formBox');
  box.innerHTML = `
    <div class="field"><label for="rCat">Category</label>
      <select id="rCat"><option value="">Choose a category</option>${(cats || []).map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></div>
    <div class="field"><label for="rTitle">Short title</label><input id="rTitle" maxlength="120" placeholder="Example: Streetlight not working on Main Road"></div>
    <div class="field"><label for="rDesc">Description</label><textarea id="rDesc" rows="4" maxlength="2000"></textarea></div>
    <div class="field"><label for="rPhoto">Photo (JPG, PNG or WebP, up to 5 MB)</label><input type="file" id="rPhoto" accept="image/jpeg,image/png,image/webp"></div>
    <div class="field"><label>Location</label>
      <button class="btn" type="button" id="locBtn">Use my current location</button></div>
    <p class="sub" style="margin-bottom:8px">Or click the map to place the marker.</p>
    <div id="map" role="application" aria-label="Map for choosing the problem location"></div>
    <div class="field" style="margin-top:14px"><label for="rAddr">Landmark or address (optional)</label><input id="rAddr" maxlength="200"></div>
    <button class="btn" type="button" id="submitBtn">Submit report</button>
    <div class="msg" id="rMsg" role="status"></div>`;

  if (reportMap) { reportMap.remove(); reportMap = null; }
  reportMap = L.map('map').setView([20.59, 78.96], 5);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap contributors' }).addTo(reportMap);
  let marker = null, pos = null;
  function setPos(lat, lng, zoom) {
    pos = { lat, lng };
    if (marker) marker.setLatLng([lat, lng]); else marker = L.marker([lat, lng]).addTo(reportMap);
    if (zoom) reportMap.setView([lat, lng], zoom);
  }
  reportMap.on('click', e => setPos(e.latlng.lat, e.latlng.lng));

  const msg = document.getElementById('rMsg');
  document.getElementById('locBtn').addEventListener('click', () => {
    if (!navigator.geolocation) { msg.textContent = 'Your browser cannot share location. Click the map instead.'; return; }
    msg.textContent = 'Finding your location…';
    navigator.geolocation.getCurrentPosition(
      p => { setPos(p.coords.latitude, p.coords.longitude, 16); msg.textContent = 'Location set. Drag the map or click to adjust.'; },
      () => { msg.textContent = 'Could not get your location. Click the map instead.'; });
  });

  document.getElementById('submitBtn').addEventListener('click', async () => {
    const cat = document.getElementById('rCat').value;
    const title = document.getElementById('rTitle').value.trim();
    const desc = document.getElementById('rDesc').value.trim();
    const file = document.getElementById('rPhoto').files[0];
    if (!cat) { msg.textContent = 'Choose a category.'; return; }
    if (title.length < 3) { msg.textContent = 'Enter a short title.'; return; }
    if (desc.length < 5) { msg.textContent = 'Add a description.'; return; }
    if (!pos) { msg.textContent = 'Mark the location on the map.'; return; }
    if (file && file.size > MAX_PHOTO) { msg.textContent = 'The photo is larger than 5 MB.'; return; }

    const btn = document.getElementById('submitBtn');
    btn.disabled = true; msg.textContent = 'Submitting…';
    let photo_path = null;
    if (file) {
      const ext = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' }[file.type] || 'jpg';
      photo_path = `${profile.id}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
      const up = await sb.storage.from('problem-photos').upload(photo_path, file, { contentType: file.type });
      if (up.error) { msg.textContent = 'Photo upload failed. Try a smaller image.'; btn.disabled = false; return; }
    }
    const { error } = await sb.from('problems').insert({
      category_id: Number(cat), title, description: desc, photo_path,
      latitude: pos.lat, longitude: pos.lng,
      address: document.getElementById('rAddr').value.trim() || null
    });
    if (error) { msg.textContent = 'Could not save the report. Try again.'; btn.disabled = false; return; }
    location.hash = '#reports';
  });
}

async function renderMyReports(view, profile) {
  view.innerHTML = '<h1>My reports</h1><p class="sub">Loading…</p>';
  const { data, error } = await sb.from('problems')
    .select('id, title, description, photo_path, address, status, created_at, categories(name)')
    .eq('reporter_id', profile.id).order('created_at', { ascending: false });
  if (error) { view.innerHTML = '<h1>My reports</h1><p class="sub">Could not load your reports. Check that 02_problems.sql was run.</p>'; return; }
  if (!data.length) {
    view.innerHTML = '<h1>My reports</h1><div class="empty">You have not reported anything yet.<br><a class="phase" href="#report">Report a problem</a></div>';
    return;
  }
  view.innerHTML = `<h1>My reports</h1><p class="sub">Each report moves through five stages.</p>` + data.map(p => {
    const idx = STATUS_STEPS.findIndex(s => s[0] === p.status);
    const url = photoUrl(p.photo_path);
    return `<div class="panel report">
      ${url ? `<img src="${esc(url)}" alt="Photo for ${esc(p.title)}" loading="lazy">` : ''}
      <div><h2>${esc(p.title)}</h2>
      <p class="meta">${esc(p.categories ? p.categories.name : '')} · ${esc(new Date(p.created_at).toLocaleDateString())}${p.address ? ' · ' + esc(p.address) : ''}</p>
      <p>${esc(p.description)}</p>
      <ol class="track">${STATUS_STEPS.map((s, i) => `<li class="${i < idx ? 'done' : i === idx ? 'now' : ''}">${s[1]}</li>`).join('')}</ol></div></div>`;
  }).join('');
}

async function citizenOverviewStats(profile) {
  const { data } = await sb.from('problems').select('status').eq('reporter_id', profile.id);
  const rows = data || [];
  const n = f => rows.filter(f).length;
  return [['Reports submitted', rows.length], ['In progress', n(r => r.status === 'assigned' || r.status === 'in_progress')], ['Resolved', n(r => r.status === 'resolved')]];
}
