// Builds a role dashboard. Needs supabase-config.js and auth.js loaded first.
const ROLE_LABELS = { citizen: 'Citizen', volunteer: 'Volunteer', ngo: 'NGO', admin: 'Administrator' };

const CONFIG = {
  citizen: {
    intro: 'Report problems in your community and follow their progress.',
    stats: [['Reports submitted', 0], ['In progress', 0], ['Resolved', 0]],
    nav: [
      { id: 'overview', label: 'Overview' },
      { id: 'report', label: 'Report a problem', phase: 5, desc: 'Upload a photo, pick a category, describe the issue and mark its location on the map.' },
      { id: 'reports', label: 'My reports', phase: 5, desc: 'Follow each report as it moves from Reported to Verified, Assigned, In Progress and Resolved.' },
      { id: 'profile', label: 'Profile' }
    ]
  },
  volunteer: {
    intro: 'Find opportunities, complete tasks and build your volunteering record.',
    stats: [['Events joined', 0], ['Active tasks', 0], ['Hours volunteered', 0]],
    nav: [
      { id: 'overview', label: 'Overview' },
      { id: 'opportunities', label: 'Find opportunities', phase: 6, desc: 'Browse events published by NGOs and join the ones that suit your skills and time.' },
      { id: 'tasks', label: 'My tasks', phase: 7, desc: 'Accept tasks assigned to you and upload before-and-after photos when finished.' },
      { id: 'hours', label: 'Hours and certificates', phase: 9, desc: 'See your total hours and download certificates for verified participation.' },
      { id: 'profile', label: 'Profile' }
    ]
  },
  ngo: {
    intro: 'Organize events, manage volunteers and verify completed work.',
    stats: [['Events created', 0], ['Registered volunteers', 0], ['Awaiting verification', 0]],
    nav: [
      { id: 'overview', label: 'Overview' },
      { id: 'events', label: 'My events', phase: 6, desc: 'Create events, publish opportunities and manage volunteer registrations.' },
      { id: 'problems', label: 'Community problems', phase: 7, desc: 'View reported problems and assign them to volunteers as tasks.' },
      { id: 'verify', label: 'Verify work', phase: 8, desc: 'Compare before-and-after photos and approve completed work.' },
      { id: 'profile', label: 'Profile' }
    ]
  },
  admin: {
    intro: 'Monitor the platform and manage its users.',
    stats: null,
    nav: [
      { id: 'overview', label: 'Overview' },
      { id: 'users', label: 'All users' },
      { id: 'verification', label: 'Verify NGOs and reports', phase: 10, desc: 'Approve NGO accounts and confirm that reported problems are genuine.' },
      { id: 'profile', label: 'Profile' }
    ]
  }
};

function esc(v) {
  return String(v == null ? '' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

async function initDashboard(role) {
  const profile = await requireRole(role);
  if (!profile) return;
  const cfg = CONFIG[role];
  const { data: { user } } = await sb.auth.getUser();

  document.getElementById('app').innerHTML = `
    <header class="topbar">
      <a class="brand" href="index.html">VolunteerConnect</a>
      <div class="who"><span class="name">${esc(profile.full_name || user.email)}</span>
        <span class="badge">${ROLE_LABELS[role]}</span>
        <button class="btn ghost" id="logoutBtn" type="button">Log out</button></div>
    </header>
    <div class="layout">
      <nav class="nav" aria-label="Dashboard">
        ${cfg.nav.map(n => `<a href="#${n.id}" data-id="${n.id}">${esc(n.label)}</a>`).join('')}
      </nav>
      <main id="view" tabindex="-1"></main>
    </div>`;
  document.getElementById('logoutBtn').addEventListener('click', logout);

  const view = document.getElementById('view');

  function statCards(list) {
    return `<div class="stats">${list.map(([label, n]) => `<div class="stat"><strong>${esc(n)}</strong>${esc(label)}</div>`).join('')}</div>`;
  }

  async function renderOverview() {
    let stats = cfg.stats;
    if (role === 'citizen') stats = await citizenOverviewStats(profile);
    if (role === 'admin') {
      const { data } = await sb.from('profiles').select('role');
      const rows = data || [];
      const count = r => rows.filter(x => x.role === r).length;
      stats = [['Total users', rows.length], ['Citizens', count('citizen')], ['Volunteers', count('volunteer')], ['NGOs', count('ngo')]];
    }
    view.innerHTML = `<h1>Welcome, ${esc(profile.full_name || 'there')}</h1><p class="sub">${esc(cfg.intro)}</p>
      ${statCards(stats)}
      <div class="panel"><h2>Getting started</h2><p>Use the menu to move around. Sections marked as coming soon will switch on as the platform is built.</p></div>`;
    if (role !== 'admin' && role !== 'citizen') {
      view.querySelector('.panel').insertAdjacentHTML('afterend', '<p class="sub">Counts show 0 until the activity tables are added.</p>');
    }
  }

  async function renderUsers() {
    view.innerHTML = '<h1>All users</h1><p class="sub">Loading…</p>';
    const { data, error } = await sb.from('profiles').select('full_name, role, organization, created_at').order('created_at', { ascending: false }).limit(100);
    if (error) { view.innerHTML = '<h1>All users</h1><p class="sub">Could not load users. Check that the admin policy from 01_profiles.sql was created.</p>'; return; }
    view.innerHTML = `<h1>All users</h1><p class="sub">Newest 100 accounts.</p>
      <div class="panel tablewrap"><table><thead><tr><th>Name</th><th>Role</th><th>Organization</th><th>Joined</th></tr></thead><tbody>
      ${data.map(u => `<tr><td>${esc(u.full_name || '—')}</td><td>${esc(ROLE_LABELS[u.role] || u.role)}</td><td>${esc(u.organization || '—')}</td><td>${esc(new Date(u.created_at).toLocaleDateString())}</td></tr>`).join('')}
      </tbody></table></div>`;
  }

  function renderProfile() {
    view.innerHTML = `<h1>Profile</h1><p class="sub">Your account details.</p>
      <div class="panel">
        <div class="field"><label for="pEmail">Email</label><input id="pEmail" value="${esc(user.email)}" disabled></div>
        <div class="field"><label for="pRole">Role</label><input id="pRole" value="${esc(ROLE_LABELS[role])}" disabled></div>
        <div class="field"><label for="pName">Full name</label><input id="pName" value="${esc(profile.full_name)}"></div>
        ${role === 'ngo' ? `<div class="field"><label for="pOrg">Organization name</label><input id="pOrg" value="${esc(profile.organization)}"></div>` : ''}
        <button class="btn" id="saveBtn" type="button">Save changes</button>
        <div class="msg" id="pMsg" role="status"></div>
      </div>`;
    document.getElementById('saveBtn').addEventListener('click', async () => {
      const update = { full_name: document.getElementById('pName').value.trim() };
      if (role === 'ngo') update.organization = document.getElementById('pOrg').value.trim();
      const { error } = await sb.from('profiles').update(update).eq('id', profile.id);
      document.getElementById('pMsg').textContent = error ? 'Could not save. Try again.' : 'Saved.';
      if (!error) Object.assign(profile, update);
    });
  }

  function renderPlaceholder(item) {
    view.innerHTML = `<h1>${esc(item.label)}</h1><p class="sub">${esc(item.desc)}</p>
      <div class="empty">Nothing here yet.<br><span class="phase">Coming in Phase ${item.phase}</span></div>`;
  }

  async function show() {
    const id = location.hash.slice(1) || 'overview';
    const item = cfg.nav.find(n => n.id === id) || cfg.nav[0];
    document.querySelectorAll('.nav a').forEach(a => {
      const on = a.dataset.id === item.id;
      a.classList.toggle('active', on);
      if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    if (item.id === 'overview') await renderOverview();
    else if (item.id === 'profile') renderProfile();
    else if (item.id === 'users') await renderUsers();
    else if (role === 'citizen' && item.id === 'report') await renderReportForm(view, profile);
    else if (role === 'citizen' && item.id === 'reports') await renderMyReports(view, profile);
    else renderPlaceholder(item);
  }
  window.addEventListener('hashchange', show);
  show();
}
